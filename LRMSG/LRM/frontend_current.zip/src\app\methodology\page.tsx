"use client";

import { mockModelMetrics } from "@/mock/data";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

const DATA_SOURCES = [
  { title: "Satellite Imagery", desc: "Sentinel-2, Landsat-8/9 for NDVI, land cover, terrain analysis" },
  { title: "Weather Stations", desc: "IMD rainfall data, temperature, humidity from ground stations" },
  { title: "Digital Elevation Model", desc: "SRTM 30m DEM for slope, aspect, elevation, terrain derivatives" },
  { title: "Soil Data", desc: "WRB soil classification, AHC soil groups, moisture retention" },
];

const PIPELINE = [
  { step: "Raw Geospatial Data", sub: "Satellite, DEM, Weather, Soil" },
  { step: "Preprocessing", sub: "Cleaning, normalization, gap-filling" },
  { step: "Feature Engineering", sub: "Spatial + temporal feature extraction" },
  { step: "XGBoost Model", sub: "Layer 1: Landslide probability prediction" },
  { step: "AHC Clustering", sub: "Layer 2: Susceptibility classification" },
  { step: "Decision Model", sub: "Layer 3: Final risk decision" },
  { step: "Risk Visualization", sub: "Interactive GIS display and reporting" },
];

export default function MethodologyPage() {
  const metrics = mockModelMetrics();

  return (
    <main>
      <section className="content" style={{ maxWidth: "1000px" }}>
        <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
          <div className="section-heading">
            <div>
              <p className="eyebrow">TECHNICAL DOCUMENTATION</p>
              <h2>Methodology</h2>
            </div>
          </div>
        </Motion>

        {/* Data Sources */}
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card" style={{ marginBottom: "20px" }}>
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>DATA SOURCES</p>
            </div>
            <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "12px" }}>
                {DATA_SOURCES.map((src) => (
                  <Motion key={src.title} variants={cardReveal}>
                    <div style={{ background: "var(--surface)", border: "1px solid var(--line)", borderRadius: "3px", padding: "14px" }}>
                      <p style={{ fontFamily: "'DM Mono', monospace", fontWeight: 700, fontSize: "11px", color: "var(--text-primary)", margin: "0 0 4px" }}>{src.title}</p>
                      <p style={{ fontSize: "11px", color: "var(--text-secondary)", margin: 0, lineHeight: 1.5 }}>{src.desc}</p>
                    </div>
                  </Motion>
                ))}
              </div>
            </Motion>
          </div>
        </Motion>

        {/* Pipeline */}
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card" style={{ marginBottom: "20px" }}>
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>PREDICTION PIPELINE</p>
            </div>
            <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {PIPELINE.map((step, i) => (
                  <Motion key={step.step} variants={fadeInUp}>
                    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                      <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: "var(--accent)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", flexShrink: 0 }}>
                        {i + 1}
                      </div>
                      <div style={{ flex: 1, background: "var(--surface)", border: "1px solid var(--line)", borderRadius: "3px", padding: "10px 14px" }}>
                        <p style={{ fontFamily: "'DM Mono', monospace", fontSize: "12px", fontWeight: 600, color: "var(--text-primary)", margin: 0 }}>{step.step}</p>
                        <p style={{ fontSize: "10px", color: "var(--text-secondary)", margin: "2px 0 0" }}>{step.sub}</p>
                      </div>
                      {i < PIPELINE.length - 1 && <span style={{ color: "var(--text-secondary)", fontSize: "14px" }}>↓</span>}
                    </div>
                  </Motion>
                ))}
              </div>
            </Motion>
          </div>
        </Motion>

        {/* ML Architecture */}
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card" style={{ marginBottom: "20px" }}>
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>ML ARCHITECTURE</p>
            </div>
            <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "14px" }}>
                {[
                  { title: "Layer 1: XGBoost", desc: "Gradient-boosted decision tree trained on 12 engineered features including soil moisture indices, rainfall, and temporal derivatives. Outputs landslide probability." },
                  { title: "Layer 2: AHC Clustering", desc: "Agglomerative Hierarchical Clustering groups locations by soil type, terrain, and moisture. Each cluster has a frozen susceptibility score." },
                  { title: "Layer 3: Decision Model", desc: "XGBoost meta-model combines XGBoost probability and AHC cluster output. Produces the final risk prediction." },
                ].map((layer) => (
                  <Motion key={layer.title} variants={cardReveal}>
                    <div style={{ borderTop: "3px solid var(--accent)", background: "var(--surface)", border: "1px solid var(--line)", borderRadius: "3px", padding: "16px" }}>
                      <p style={{ fontFamily: "'DM Mono', monospace", fontWeight: 700, fontSize: "11px", color: "var(--accent-text)", margin: "0 0 8px", letterSpacing: "0.5px" }}>{layer.title}</p>
                      <p style={{ fontSize: "11px", color: "var(--text-secondary)", margin: 0, lineHeight: 1.6 }}>{layer.desc}</p>
                    </div>
                  </Motion>
                ))}
              </div>
            </Motion>
          </div>
        </Motion>

        {/* Model Metrics */}
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card" style={{ marginBottom: "20px" }}>
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>MODEL EVALUATION</p>
            </div>
            <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: "12px" }}>
                {[
                  { label: "Accuracy", value: `${(metrics.accuracy * 100).toFixed(1)}%` },
                  { label: "Precision", value: `${(metrics.precision * 100).toFixed(1)}%` },
                  { label: "Recall", value: `${(metrics.recall * 100).toFixed(1)}%` },
                  { label: "F1 Score", value: `${(metrics.f1 * 100).toFixed(1)}%` },
                  { label: "ROC-AUC", value: metrics.rocAuc.toFixed(4) },
                  { label: "PR-AUC", value: metrics.prAuc.toFixed(4) },
                ].map((m) => (
                  <Motion key={m.label} variants={cardReveal}>
                    <div style={{ textAlign: "center", padding: "12px", background: "var(--surface)", border: "1px solid var(--line)", borderRadius: "3px" }}>
                      <p style={{ fontSize: "10px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", margin: 0, letterSpacing: "0.5px" }}>{m.label}</p>
                      <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "22px", fontWeight: 700, margin: "6px 0 0", color: "var(--text-primary)" }}>{m.value}</p>
                    </div>
                  </Motion>
                ))}
              </div>
            </Motion>
          </div>
        </Motion>

        {/* Soil Types */}
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card">
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>AHC SOIL CATEGORIES</p>
            </div>
            <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
              {["Acrisols", "Cambisols", "Fluvisols", "Leptosols", "Luvisols", "Vertisols"].map((soil) => (
                <span key={soil} style={{ background: "var(--surface)", border: "1px solid var(--line)", padding: "8px 14px", borderRadius: "3px", fontFamily: "'DM Mono', monospace", fontSize: "11px", fontWeight: 600, color: "var(--text-primary)" }}>
                  {soil}
                </span>
              ))}
            </div>
          </div>
        </Motion>
      </section>
    </main>
  );
}

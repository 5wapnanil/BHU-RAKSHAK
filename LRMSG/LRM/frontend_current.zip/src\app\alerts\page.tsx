"use client";

import { mockAlerts } from "@/mock/data";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

export default function AlertsPage() {
  const alerts = mockAlerts();
  const sorted = [...alerts].sort((a, b) => {
    const order = { critical: 0, high: 1, moderate: 2, info: 3 };
    return order[a.severity] - order[b.severity];
  });

  return (
    <main>
      <section className="content">
        <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
          <div className="section-heading">
            <div>
              <p className="eyebrow">LIVE ALERT FEED</p>
              <h2>Risk Alerts</h2>
            </div>
            <p className="sim-note">{sorted.length} ACTIVE ALERTS</p>
          </div>
        </Motion>

        <Motion initial="hidden" animate="visible" variants={staggerContainer}>
          <div style={{ display: "grid", gap: "12px" }}>
            {sorted.map((alert) => {
              const timeDiff = Date.now() - new Date(alert.timestamp).getTime();
              const hours = Math.floor(timeDiff / 3600000);
              const mins = Math.floor((timeDiff % 3600000) / 60000);
              const timeAgo = hours > 0 ? `${hours}h ${mins}m ago` : `${mins}m ago`;

              return (
                <Motion key={alert.id} variants={cardReveal}>
                  <div className={`alert-item ${alert.severity}`}>
                    <div className="alert-meta">
                      <span className={`level-tag ${alert.severity}`} style={{ fontSize: "9px" }}>
                        {alert.severity.toUpperCase()}
                      </span>
                      <span>RISK ALERT</span>
                      <span style={{ marginLeft: "auto" }}>{timeAgo}</span>
                    </div>
                    <div style={{ fontSize: "13px", fontWeight: 600, marginBottom: "6px", fontFamily: "'Space Grotesk', sans-serif", color: "var(--text-primary)" }}>
                      {alert.location}
                    </div>
                    <p style={{ margin: "0 0 8px", fontSize: "12px", lineHeight: 1.6, fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)" }}>
                      {alert.message}
                    </p>
                    {alert.riskChange && (
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "10px", fontFamily: "'DM Mono', monospace" }}>
                        <span style={{ color: "var(--text-secondary)" }}>Risk change:</span>
                        <span className={`level-tag ${alert.riskChange.from}`} style={{ fontSize: "9px", padding: "2px 6px" }}>
                          {alert.riskChange.from.toUpperCase()}
                        </span>
                        <span style={{ color: "var(--text-secondary)" }}>→</span>
                        <span className={`level-tag ${alert.riskChange.to}`} style={{ fontSize: "9px", padding: "2px 6px" }}>
                          {alert.riskChange.to.toUpperCase()}
                        </span>
                      </div>
                    )}
                  </div>
                </Motion>
              );
            })}
          </div>
        </Motion>
      </section>
    </main>
  );
}

"use client";

import { useState } from "react";
import { Loader2, BarChart3 } from "lucide-react";
import { mockSoilTypes } from "@/mock/data";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

const SOIL_TYPES = mockSoilTypes();

function getRiskLevel(prob: number): string {
  if (prob >= 0.80) return "Extreme";
  if (prob >= 0.60) return "Very High";
  if (prob >= 0.40) return "High";
  if (prob >= 0.20) return "Moderate";
  return "Low";
}

export default function PredictionPage() {
  const [form, setForm] = useState({
    latitude: "27.041",
    longitude: "88.2663",
    rainfall: "182",
    soilMoisture: "0.63",
    slope: "31.2",
    elevation: "2148",
    ndvi: "0.42",
    temperature: "18.4",
    soilType: "Cambisols",
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    probability: number;
    prediction: number;
    xgboost: number;
    ahcCluster: number;
    ahcSusceptibility: number;
  } | null>(null);

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setResult(null);
  };

  const handlePredict = async () => {
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/prediction/location", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          latitude: parseFloat(form.latitude) || 27.041,
          longitude: parseFloat(form.longitude) || 88.2663,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || "Prediction failed");
      }

      const data = await response.json();
      
      // Update the UI inputs so the user sees the real data that the backend fetched
      if (data.features) {
        setForm(prev => ({
          ...prev,
          rainfall: data.features.rainfall.toFixed(1),
          soilMoisture: data.features.soilMoisture.toFixed(2),
          slope: data.features.slope.toFixed(1),
          elevation: data.features.elevation.toFixed(0),
          soilType: data.features.soilType,
        }));
      }

      setResult({
        probability: data.final_decision.probability,
        prediction: data.final_decision.prediction,
        xgboost: data.xgboost.probability,
        ahcCluster: data.ahc.cluster,
        ahcSusceptibility: data.ahc.susceptibility,
      });
    } catch (error) {
      console.error(error);
      alert("Error: " + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleCustomPredict = async () => {
    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/prediction/custom", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rainfall: parseFloat(form.rainfall) || 0,
          soilMoisture: parseFloat(form.soilMoisture) || 0,
          slope: parseFloat(form.slope) || 0,
          elevation: parseFloat(form.elevation) || 0,
          soilType: form.soilType || "Cambisols",
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.detail || "Prediction failed");
      }

      const data = await response.json();
      
      setResult({
        probability: data.final_decision.probability,
        prediction: data.final_decision.prediction,
        xgboost: data.xgboost.probability,
        ahcCluster: data.ahc.cluster,
        ahcSusceptibility: data.ahc.susceptibility,
      });
    } catch (error) {
      console.error(error);
      alert("Error: " + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main>
      <section className="content">
        <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
          <div className="section-heading">
            <div>
              <p className="eyebrow">RESEARCH PROTOTYPE / DECISION-SUPPORT FRAMEWORK</p>
              <h2>Location Analysis</h2>
            </div>
            <p className="sim-note">THIS IS A PROTOTYPE EARLY-WARNING FRAMEWORK. NOT A CERTIFIED EMERGENCY SYSTEM.</p>
          </div>
        </Motion>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
          {/* Input form */}
          <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4, delay: 0.1 }}>
            <div className="card">
              <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
                <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>ENVIRONMENTAL PARAMETERS</p>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", marginBottom: "16px" }}>
                <div className="form-field">
                  <label>LATITUDE</label>
                  <input type="number" step="any" value={form.latitude} onChange={(e) => handleChange("latitude", e.target.value)} />
                </div>
                <div className="form-field">
                  <label>LONGITUDE</label>
                  <input type="number" step="any" value={form.longitude} onChange={(e) => handleChange("longitude", e.target.value)} />
                </div>
              </div>

              <div style={{ borderTop: "1px solid var(--line)", paddingTop: "16px", marginBottom: "16px" }}>
                <p style={{ fontSize: "10px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: "0 0 14px" }}>XGBOOST FEATURES</p>
                <div style={{ display: "grid", gap: "14px" }}>
                  <div className="form-field">
                    <label>RAINFALL (mm)</label>
                    <input type="number" value={form.rainfall} onChange={(e) => handleChange("rainfall", e.target.value)} />
                  </div>
                  <div className="form-field">
                    <label>SOIL MOISTURE (0-1)</label>
                    <input type="number" step="0.01" value={form.soilMoisture} onChange={(e) => handleChange("soilMoisture", e.target.value)} />
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                    <div className="form-field">
                      <label>SLOPE (degrees)</label>
                      <input type="number" step="0.1" value={form.slope} onChange={(e) => handleChange("slope", e.target.value)} />
                    </div>
                    <div className="form-field">
                      <label>ELEVATION (m)</label>
                      <input type="number" value={form.elevation} onChange={(e) => handleChange("elevation", e.target.value)} />
                    </div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                    <div className="form-field">
                      <label>NDVI</label>
                      <input type="number" step="0.01" value={form.ndvi} onChange={(e) => handleChange("ndvi", e.target.value)} />
                    </div>
                    <div className="form-field">
                      <label>TEMPERATURE (°C)</label>
                      <input type="number" step="0.1" value={form.temperature} onChange={(e) => handleChange("temperature", e.target.value)} />
                    </div>
                  </div>
                  <div className="form-field">
                    <label>SOIL TYPE</label>
                    <select value={form.soilType} onChange={(e) => handleChange("soilType", e.target.value)}>
                      {SOIL_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", gap: "10px" }}>
                <button className="btn-primary" onClick={handlePredict} disabled={loading} style={{ flex: 1, padding: "12px 0", fontSize: "10px" }}>
                  {loading ? <span className="flex items-center justify-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> RUNNING...</span> : "RUN (LIVE API)"}
                </button>
                <button className="btn-primary" onClick={handleCustomPredict} disabled={loading} style={{ flex: 1, padding: "12px 0", fontSize: "10px", background: "var(--surface)", color: "var(--text-primary)", border: "1px solid var(--line)" }}>
                  {loading ? <span className="flex items-center justify-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> RUNNING...</span> : "RUN (USER INPUT)"}
                </button>
              </div>
            </div>
          </Motion>

          {/* Results */}
          <div style={{ display: "grid", gap: "16px" }}>
            {result ? (
              <Motion initial="hidden" animate="visible" variants={staggerContainer}>
                <Motion variants={cardReveal}>
                  <div className="card" style={{ textAlign: "center", padding: "32px" }}>
                    <p style={{ fontSize: "10px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: "0 0 8px" }}>LANDSLIDE RISK</p>
                    <span className={`level-tag ${getRiskLevel(result.probability).replace(' ', '-').toLowerCase()}`} style={{ fontSize: "14px", padding: "8px 16px" }}>
                      {getRiskLevel(result.probability).toUpperCase()}
                    </span>
                    <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "56px", fontWeight: 700, margin: "12px 0 4px", lineHeight: 1, letterSpacing: "-2px", color: "var(--text-primary)" }}>
                      {Math.round(result.probability * 100)}%
                    </div>
                    <p style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", color: "var(--text-secondary)", margin: 0 }}>Prediction Probability</p>
                  </div>
                </Motion>

                <Motion variants={cardReveal}>
                  <div className="card">
                    <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "12px" }}>
                      <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>ML PIPELINE RESULTS</p>
                    </div>
                    <div style={{ display: "grid", gap: "8px", fontFamily: "'DM Mono', monospace", fontSize: "11px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 10px", background: "var(--surface)", borderRadius: "3px" }}>
                        <span style={{ color: "var(--text-secondary)" }}>XGBoost Probability</span>
                        <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>{(result.xgboost * 100).toFixed(1)}%</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 10px", background: "var(--surface)", borderRadius: "3px" }}>
                        <span style={{ color: "var(--text-secondary)" }}>AHC Cluster</span>
                        <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>Cluster {result.ahcCluster}</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 10px", background: "var(--surface)", borderRadius: "3px" }}>
                        <span style={{ color: "var(--text-secondary)" }}>AHC Susceptibility</span>
                        <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>{result.ahcSusceptibility.toFixed(2)}</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 10px", background: "var(--accent)", borderRadius: "3px", color: "#fff" }}>
                        <span>Final Prediction</span>
                        <span style={{ fontWeight: 700 }}>{(result.probability * 100).toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>
                </Motion>

                <Motion variants={cardReveal}>
                  <div className="card">
                    <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "12px" }}>
                      <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>FEATURE VALUES</p>
                    </div>
                    <div style={{ display: "grid", gap: "4px", fontFamily: "'DM Mono', monospace", fontSize: "11px" }}>
                      {[
                        { label: "Rainfall", value: `${form.rainfall} mm` },
                        { label: "Soil Moisture", value: `${Math.round(parseFloat(form.soilMoisture) * 100)}%` },
                        { label: "Slope", value: `${form.slope}°` },
                        { label: "Elevation", value: `${form.elevation} m` },
                        { label: "NDVI", value: form.ndvi },
                        { label: "Temperature", value: `${form.temperature}°C` },
                        { label: "Soil Type", value: form.soilType },
                      ].map((f) => (
                        <div key={f.label} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid var(--line)" }}>
                          <span style={{ color: "var(--text-secondary)" }}>{f.label}</span>
                          <span style={{ fontWeight: 600, color: "var(--text-primary)" }}>{f.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </Motion>
              </Motion>
            ) : (
              <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4, delay: 0.2 }}>
                <div className="card" style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "300px" }}>
                  <div style={{ textAlign: "center", color: "var(--text-secondary)", fontFamily: "'DM Mono', monospace" }}>
                    <BarChart3 className="mx-auto mb-3 h-8 w-8 opacity-30" />
                    <p style={{ fontSize: "11px", letterSpacing: "1px" }}>ENTER PARAMETERS AND RUN PREDICTION</p>
                  </div>
                </div>
              </Motion>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}

"use client";

import Link from "next/link";
import dynamic from "next/dynamic";
import { mockZones } from "@/mock/data";
import { TypingEffect } from "@/components/ui/typing-effect";
import { InsightsSection } from "@/components/insights/InsightsSection";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

const MapBackground = dynamic(() => import("@/components/map/MapBackground"), { ssr: false });

export default function HomePage() {
  const zones = mockZones();
  const totalDistricts = zones.length;
  const warningCount = zones.filter((z) => z.risk_level === "high" || z.risk_level === "critical").length;
  const criticalCount = zones.filter((z) => z.risk_level === "critical").length;

  return (
    <main style={{ position: "relative" }}>
      <MapBackground />
      <div style={{ position: "relative", zIndex: 1 }}>

      <section className="hero">
        <div style={{ textAlign: "center", maxWidth: "800px", margin: "0 auto" }}>
          <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.5 }}>
            <div className="eyebrow" style={{ justifyContent: "center", display: "flex", minHeight: "3em" }}>
              <TypingEffect
                texts={["AI-POWERED LANDSLIDE RISK INTELLIGENCE", "REAL-TIME MONITORING SYSTEM", "PREDICT & PROTECT LIVES"]}
                rotationInterval={3000}
                typingSpeed={80}
                className="text-2xl"
              />
            </div>
          </Motion>
          <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.5, delay: 0.1 }}>
            <h1 style={{ textAlign: "center" }}>Predict the risk.<br /><em>Protect the lives.</em></h1>
          </Motion>
          <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.5, delay: 0.2 }}>
            <p className="lede" style={{ textAlign: "center", maxWidth: "600px", margin: "24px auto 0", color: "#000" }}>
              Three-layer machine learning pipeline combining XGBoost classification, AHC clustering, and spatial decision models for landslide risk prediction across Northeast India.
            </p>
          </Motion>
          <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.5, delay: 0.3 }}>
            <div style={{ marginTop: "48px", display: "flex", justifyContent: "center", gap: "12px" }}>
              <Link href="/risk-map" style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", fontWeight: 700, letterSpacing: "1px", padding: "12px 24px", background: "var(--accent)", color: "#fff", border: "none", borderRadius: "3px", textDecoration: "none", cursor: "pointer" }}>
                EXPLORE RISK MAP →
              </Link>
              <Link href="/prediction" style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", fontWeight: 700, letterSpacing: "1px", padding: "12px 24px", background: "var(--paper)", color: "var(--text-primary)", border: "1px solid var(--line)", borderRadius: "3px", textDecoration: "none", cursor: "pointer" }}>
                RUN PREDICTION
              </Link>
            </div>
          </Motion>
          <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.5, delay: 0.4 }}>
            <div style={{ marginTop: "80px", fontFamily: "'DM Mono', monospace", fontSize: "10px", color: "#000", letterSpacing: "1px", animation: "pulse 2s ease-in-out infinite" }}>
              ↓ SCROLL TO EXPLORE
            </div>
          </Motion>
        </div>
      </section>

      <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={staggerContainer}>
        <section className="summary">
          <Motion variants={fadeInUp}>
            <div>
              <span>DISTRICTS MONITORED</span>
              <strong>{totalDistricts}</strong>
            </div>
          </Motion>
          <Motion variants={fadeInUp}>
            <div>
              <span>WARNING TIER</span>
              <strong className="amber">{warningCount}</strong>
            </div>
          </Motion>
          <Motion variants={fadeInUp}>
            <div>
              <span>CRITICAL TIER</span>
              <strong className="red">{criticalCount}</strong>
            </div>
          </Motion>
          <Motion variants={fadeInUp}>
            <div className="summary-note">
              LIVE TELEMETRY &amp; ML SENSING<br />
              Soil Moisture · Rainfall · Terrain · AHC Clustering
            </div>
          </Motion>
        </section>
      </Motion>

      <section className="content">
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="section-heading">
            <div>
              <p className="eyebrow">SYSTEM CAPABILITIES</p>
              <h2>Platform Overview</h2>
            </div>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={staggerContainer}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "16px", marginBottom: "32px" }}>
            <Motion variants={cardReveal}>
              <div className="card" style={{ borderTop: "3px solid var(--green)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                  <span style={{ fontSize: "11px", fontWeight: 700, color: "var(--green)", fontFamily: "'DM Mono', monospace" }}>MAP</span>
                  <span style={{ fontSize: "10px", fontWeight: 700, background: "var(--green-dim)", color: "var(--green)", padding: "2px 6px", borderRadius: "2px", fontFamily: "'DM Mono', monospace" }}>GIS</span>
                </div>
                <p style={{ fontSize: "12px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", lineHeight: 1.5, margin: "8px 0 0" }}>
                  Interactive risk map with district-level markers, risk color coding, and environmental layer visualization.
                </p>
                <Link href="/risk-map" className="block mt-3 text-xs no-underline" style={{ fontFamily: "'DM Mono', monospace", color: "var(--accent-text)" }}>
                  Open Risk Map →
                </Link>
              </div>
            </Motion>

            <Motion variants={cardReveal}>
              <div className="card" style={{ borderTop: "3px solid var(--accent)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                  <span style={{ fontSize: "11px", fontWeight: 700, color: "var(--accent-text)", fontFamily: "'DM Mono', monospace" }}>PREDICT</span>
                  <span style={{ fontSize: "10px", fontWeight: 700, background: "var(--surface)", color: "var(--accent-text)", padding: "2px 6px", borderRadius: "2px", fontFamily: "'DM Mono', monospace" }}>ML</span>
                </div>
                <p style={{ fontSize: "12px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", lineHeight: 1.5, margin: "8px 0 0" }}>
                  Enter environmental parameters and run the three-layer prediction pipeline. View XGBoost, AHC, and decision model outputs.
                </p>
                <Link href="/prediction" className="block mt-3 text-xs no-underline" style={{ fontFamily: "'DM Mono', monospace", color: "var(--accent-text)" }}>
                  Run Prediction →
                </Link>
              </div>
            </Motion>

            <Motion variants={cardReveal}>
              <div className="card" style={{ borderTop: "3px solid var(--amber)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                  <span style={{ fontSize: "11px", fontWeight: 700, color: "var(--amber)", fontFamily: "'DM Mono', monospace" }}>ALERTS</span>
                  <span style={{ fontSize: "10px", fontWeight: 700, background: "var(--surface)", color: "var(--amber)", padding: "2px 6px", borderRadius: "2px", fontFamily: "'DM Mono', monospace" }}>LIVE</span>
                </div>
                <p style={{ fontSize: "12px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", lineHeight: 1.5, margin: "8px 0 0" }}>
                  Real-time risk alerts with severity classification, location targeting, and risk change notifications.
                </p>
                <Link href="/alerts" className="block mt-3 text-xs no-underline" style={{ fontFamily: "'DM Mono', monospace", color: "var(--accent-text)" }}>
                  View Alerts →
                </Link>
              </div>
            </Motion>

            <Motion variants={cardReveal}>
              <div className="card" style={{ borderTop: "3px solid var(--red)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                  <span style={{ fontSize: "11px", fontWeight: 700, color: "var(--red)", fontFamily: "'DM Mono', monospace" }}>METHODOLOGY</span>
                  <span style={{ fontSize: "10px", fontWeight: 700, background: "var(--surface)", color: "var(--red)", padding: "2px 6px", borderRadius: "2px", fontFamily: "'DM Mono', monospace" }}>DOCS</span>
                </div>
                <p style={{ fontSize: "12px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", lineHeight: 1.5, margin: "8px 0 0" }}>
                  Technical documentation of the ML pipeline, data sources, model evaluation, and feature engineering process.
                </p>
                <Link href="/methodology" className="block mt-3 text-xs no-underline" style={{ fontFamily: "'DM Mono', monospace", color: "var(--accent-text)" }}>
                  Read Docs →
                </Link>
              </div>
            </Motion>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div style={{ marginBottom: "48px" }}>
            <InsightsSection />
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card" style={{ borderTop: "3px solid var(--accent)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: "16px", borderBottom: "1px solid var(--line)", paddingBottom: "12px" }}>
              <div>
                <p className="eyebrow" style={{ margin: 0, color: "var(--text-primary)", fontWeight: 700 }}>PIPELINE ARCHITECTURE</p>
                <p style={{ margin: "4px 0 0", fontSize: "12px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)" }}>
                  Environmental data flows through the three-layer system to produce risk predictions
                </p>
              </div>
            </div>
            <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap", fontFamily: "'DM Mono', monospace", fontSize: "11px" }}>
                {["Environmental Data", "Feature Engineering", "XGBoost Model", "AHC Clustering", "Decision Model", "Risk Prediction"].map((step, i) => (
                  <Motion key={step} variants={fadeInUp} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ background: "var(--accent)", color: "#fff", padding: "6px 12px", borderRadius: "3px", fontWeight: 700, fontSize: "10px", letterSpacing: "0.5px" }}>
                      {step}
                    </span>
                    {i < 5 && <span style={{ color: "var(--text-secondary)" }}>→</span>}
                  </Motion>
                ))}
              </div>
            </Motion>
          </div>
        </Motion>
      </section>
      </div>
    </main>
  );
}

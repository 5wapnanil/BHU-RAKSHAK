"use client";

import Link from "next/link";
import { Mountain, Map, BarChart3, Bell, BookOpen, Settings, LineChart } from "lucide-react";

const NAV_LINKS = [
  { href: "/risk-map", label: "RISK MAP", icon: Map },
  { href: "/analytics", label: "ANALYTICS", icon: LineChart },
  { href: "/prediction", label: "PREDICT", icon: BarChart3 },
  { href: "/alerts", label: "ALERTS", icon: Bell },
  { href: "/methodology", label: "METHODOLOGY", icon: BookOpen },
  { href: "/admin", label: "SYSTEM", icon: Settings },
];

export default function Navbar() {
  return (
    <header className="topbar" style={{ position: "sticky", top: 0, zIndex: 50 }}>
      <div className="brand-mark">
        <Link href="/" className="flex items-center gap-2 no-underline">
          <Mountain className="h-5 w-5" style={{ color: "var(--accent-text)" }} />
          LANDSLIDE<span>RISK</span>
        </Link>
      </div>
      <div className="flex items-center gap-6">
        <nav className="hidden md:flex items-center gap-15">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="nav-link flex items-center gap-1.5 px-4 pb-3 pt-2 text-xs no-underline"
              style={{ fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", letterSpacing: "0.5px" }}
            >
              <link.icon className="h-3 w-3" />
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}

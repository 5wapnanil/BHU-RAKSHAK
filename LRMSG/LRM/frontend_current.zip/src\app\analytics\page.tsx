"use client";

import { useState } from "react";
import {
  PieChart, Pie, Cell, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";
import { MapPin, AlertTriangle, Shield, TrendingUp, Calendar, Activity } from "lucide-react";
import {
  mockAnalyticsSummary, mockRiskDistribution, mockProbabilityDistribution,
  mockRainfallRiskTrend, mockRegionalRisk, mockHistorySummary,
  mockRainfallHistory, mockRiskScoreOverTime, mockLandslideEvents
} from "@/mock/data";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

const summary = mockAnalyticsSummary();
const riskDist = mockRiskDistribution();
const probDist = mockProbabilityDistribution();
const trendData = mockRainfallRiskTrend();
const regionalData = mockRegionalRisk();
const historySummary = mockHistorySummary();
const rainfallHistory = mockRainfallHistory();
const riskScoreData = mockRiskScoreOverTime();
const landslideEvents = mockLandslideEvents();

const TICK_STYLE = { fontFamily: "'DM Sans', sans-serif", fontSize: 11, fill: "#78716C" };

type Tab = "dashboard" | "history";

export default function AnalyticsPage() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");

  return (
    <div className="analytics-layout">
      <aside className="analytics-sidebar">
        <div className="analytics-sidebar-title">Analytics</div>
        <button
          className={`analytics-sidebar-btn ${activeTab === "dashboard" ? "active" : ""}`}
          onClick={() => setActiveTab("dashboard")}
        >
          <Activity size={16} />
          Dashboard
        </button>
        <button
          className={`analytics-sidebar-btn ${activeTab === "history" ? "active" : ""}`}
          onClick={() => setActiveTab("history")}
        >
          <Calendar size={16} />
          History
        </button>
      </aside>
      <main className="analytics-main">
        {activeTab === "dashboard" ? <DashboardView /> : <HistoryView />}
      </main>
    </div>
  );
}

function StatCard({ label, value, change, icon, color }: {
  label: string;
  value: string | number;
  change?: number;
  icon: React.ReactNode;
  color?: string;
}) {
  return (
    <Motion variants={cardReveal}>
      <div className="analytics-stat-card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div className="analytics-stat-label">{label}</div>
            <div className="analytics-stat-value">
              {typeof value === "number" ? value.toLocaleString() : value}
            </div>
            {change !== undefined && change !== 0 && (
              <div className={`analytics-stat-change ${change > 0 ? "positive" : "negative"}`}>
                {change > 0 ? "+" : ""}{change} from last month
              </div>
            )}
          </div>
          <div className="analytics-stat-icon" style={{ color: color || "var(--text-secondary)" }}>
            {icon}
          </div>
        </div>
      </div>
    </Motion>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Motion variants={cardReveal}>
      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ font: "600 15px 'Space Grotesk'", color: "var(--text-primary)", marginBottom: 20 }}>
          {title}
        </h3>
        {children}
      </div>
    </Motion>
  );
}

function DashboardView() {
  return (
    <Motion initial="hidden" animate="visible" variants={staggerContainer}>
      <div>
        <Motion variants={fadeInUp}>
          <div className="analytics-header">
            <h1>Dashboard</h1>
            <p>Risk monitoring overview across Northeast India</p>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
          <div className="analytics-stats">
            <StatCard
              label="Monitored Locations"
              value={summary.monitoredLocations}
              icon={<MapPin size={20} />}
            />
            <StatCard
              label="High Risk Areas"
              value={summary.highRiskAreas}
              change={summary.highRiskChange}
              icon={<AlertTriangle size={20} />}
              color="var(--red)"
            />
            <StatCard
              label="Moderate Risk Areas"
              value={summary.moderateRiskAreas}
              icon={<Shield size={20} />}
              color="var(--amber)"
            />
            <StatCard
              label="Low Risk Areas"
              value={summary.lowRiskAreas}
              change={summary.lowRiskChange}
              icon={<TrendingUp size={20} />}
              color="var(--green)"
            />
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
          <div className="analytics-charts">
            <ChartCard title="Risk Distribution">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={riskDist}
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {riskDist.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "var(--card-bg)",
                        border: "1px solid var(--card-border)",
                        borderRadius: 4,
                        fontFamily: "'DM Sans', sans-serif",
                        fontSize: 12,
                      }}
                    />
                    <Legend
                      iconType="square"
                      iconSize={10}
                      formatter={(value: string) => (
                        <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "var(--text-primary)" }}>
                          {value}
                        </span>
                      )}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </ChartCard>

            <ChartCard title="Risk Probability Distribution">
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={probDist}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                  <XAxis dataKey="range" tick={TICK_STYLE} />
                  <YAxis tick={TICK_STYLE} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card-bg)",
                      border: "1px solid var(--card-border)",
                      borderRadius: 4,
                      fontFamily: "'DM Sans', sans-serif",
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="count" fill="var(--accent)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
          <div className="analytics-charts">
            <ChartCard title="Rainfall vs Risk Trend">
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                  <XAxis
                    dataKey="date"
                    tick={TICK_STYLE}
                    tickFormatter={(val) => {
                      const d = new Date(val);
                      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
                    }}
                  />
                  <YAxis yAxisId="rain" tick={TICK_STYLE} />
                  <YAxis yAxisId="risk" orientation="right" tick={TICK_STYLE} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card-bg)",
                      border: "1px solid var(--card-border)",
                      borderRadius: 4,
                      fontFamily: "'DM Sans', sans-serif",
                      fontSize: 12,
                    }}
                  />
                  <Legend
                    formatter={(value: string) => (
                      <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--text-primary)" }}>{value}</span>
                    )}
                  />
                  <Line yAxisId="rain" type="monotone" dataKey="rainfall" stroke="#3B82F6" dot={false} strokeWidth={2} />
                  <Line yAxisId="risk" type="monotone" dataKey="riskScore" stroke="var(--red)" dot={false} strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Regional Risk Comparison">
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={regionalData} layout="vertical" barCategoryGap="20%">
                  <CartesianGrid strokeDasharray="3 3" stroke="#D6CCC8" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tick={TICK_STYLE} />
                  <YAxis
                    type="category"
                    dataKey="state"
                    width={130}
                    tick={TICK_STYLE}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "#FFFBF5",
                      border: "1px solid #D6CCC8",
                      borderRadius: 4,
                      fontFamily: "'DM Sans', sans-serif",
                      fontSize: 12,
                    }}
                    formatter={(value) => [`${value}%`, "Avg Risk"]}
                  />
                  <Bar dataKey="avgRisk" radius={[0, 4, 4, 0]} barSize={18}>
                    {regionalData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.avgRisk >= 70 ? "#C75B12" : entry.avgRisk >= 50 ? "#D29922" : "#3FB950"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </Motion>
      </div>
    </Motion>
  );
}

function HistoryView() {
  return (
    <Motion initial="hidden" animate="visible" variants={staggerContainer}>
      <div>
        <Motion variants={fadeInUp}>
          <div className="analytics-header">
            <h1>History</h1>
            <p>Historical data and landslide event records</p>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
          <div className="analytics-stats">
            <StatCard
              label="Total Events"
              value={historySummary.totalEvents}
              icon={<Activity size={20} />}
            />
            <StatCard
              label="Landslide Events"
              value={historySummary.landslideEvents}
              icon={<AlertTriangle size={20} />}
              color="var(--red)"
            />
            <StatCard
              label="Avg Risk Score"
              value={`${historySummary.avgRiskScore}%`}
              icon={<TrendingUp size={20} />}
              color="var(--accent)"
            />
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
          <div className="analytics-charts">
            <ChartCard title="Rainfall History">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={rainfallHistory}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                  <XAxis
                    dataKey="date"
                    tick={TICK_STYLE}
                    tickFormatter={(val) => {
                      const d = new Date(val);
                      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
                    }}
                  />
                  <YAxis tick={TICK_STYLE} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card-bg)",
                      border: "1px solid var(--card-border)",
                      borderRadius: 4,
                      fontFamily: "'DM Sans', sans-serif",
                      fontSize: 12,
                    }}
                  />
                  <Line type="monotone" dataKey="rainfall" stroke="#3B82F6" dot={false} strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Risk Score Over Time">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={riskScoreData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                  <XAxis
                    dataKey="date"
                    tick={TICK_STYLE}
                    tickFormatter={(val) => {
                      const d = new Date(val);
                      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
                    }}
                  />
                  <YAxis domain={[0, 1]} tick={TICK_STYLE} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--card-bg)",
                      border: "1px solid var(--card-border)",
                      borderRadius: 4,
                      fontFamily: "'DM Sans', sans-serif",
                      fontSize: 12,
                    }}
                  />
                  <Legend
                    formatter={(value: string) => (
                      <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--text-primary)" }}>{value}</span>
                    )}
                  />
                  <Line type="monotone" dataKey="riskScore" stroke="var(--red)" dot={false} strokeWidth={2} name="Risk Score" />
                  <Line
                    type="monotone"
                    dataKey="threshold"
                    stroke="var(--amber)"
                    strokeDasharray="5 5"
                    dot={false}
                    strokeWidth={1.5}
                    name="Threshold"
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </Motion>

        <Motion variants={cardReveal}>
          <ChartCard title={`Landslide Events (${historySummary.landslideEvents} events detected)`}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--line)" }}>
                  {["Date", "Rainfall", "Soil Moisture", "Risk Score"].map((header) => (
                    <th
                      key={header}
                      style={{
                        fontFamily: "'DM Sans', sans-serif",
                        fontSize: 12,
                        fontWeight: 600,
                        color: "var(--text-secondary)",
                        textAlign: "left",
                        padding: "12px 16px",
                      }}
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {landslideEvents.map((event, i) => (
                  <tr key={i} style={{ borderBottom: "1px solid var(--line)" }}>
                    <td style={{ padding: "12px 16px", fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-primary)" }}>
                      {event.date}
                    </td>
                    <td style={{ padding: "12px 16px", fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-primary)" }}>
                      {event.rainfall} mm
                    </td>
                    <td style={{ padding: "12px 16px", fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-primary)" }}>
                      {event.soilMoisture}%
                    </td>
                    <td style={{
                      padding: "12px 16px",
                      fontFamily: "'DM Mono', monospace",
                      fontSize: 13,
                      fontWeight: 600,
                      color: event.riskScore >= 80 ? "var(--red)" : "var(--amber)",
                    }}>
                      {event.riskScore}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </ChartCard>
        </Motion>
      </div>
    </Motion>
  );
}

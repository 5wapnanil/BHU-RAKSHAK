"use client";

import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Zone } from "@/types";

const RISK_COLORS: Record<string, { stroke: string; fill: string }> = {
  low: { stroke: "#3FB950", fill: "#238636" },
  moderate: { stroke: "#D29922", fill: "#9E6A03" },
  high: { stroke: "#F97316", fill: "#C2410C" },
  critical: { stroke: "#F85149", fill: "#DA3633" },
};

const INDIA_BOUNDS = L.latLngBounds([6.0, 68.0], [37.5, 97.5]);

export default function RiskMap({
  zones,
  selectedZoneId,
  onSelectZone,
  onLocationSelect,
}: {
  zones: Zone[];
  selectedZoneId: number | null;
  onSelectZone: (id: number) => void;
  onLocationSelect?: (lat: number, lng: number) => void;
}) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const onLocationSelectRef = useRef(onLocationSelect);
  const onSelectZoneRef = useRef(onSelectZone);

  useEffect(() => { onLocationSelectRef.current = onLocationSelect; }, [onLocationSelect]);
  useEffect(() => { onSelectZoneRef.current = onSelectZone; }, [onSelectZone]);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const map = L.map(mapRef.current, {
      center: [26.5, 92.5],
      zoom: 7,
      minZoom: 4,
      maxZoom: 14,
      maxBounds: INDIA_BOUNDS,
      maxBoundsViscosity: 0.9,
      scrollWheelZoom: false,
      zoomControl: true,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>',
      maxZoom: 19,
    }).addTo(map);

    map.on("click", (e: L.LeafletMouseEvent) => {
      const lat = parseFloat(e.latlng.lat.toFixed(2));
      const lng = parseFloat(e.latlng.lng.toFixed(2));
      if (lat >= 6.0 && lat <= 37.5 && lng >= 68.0 && lng <= 97.5) {
        onLocationSelectRef.current?.(lat, lng);
      }
    });

    const layer = L.layerGroup().addTo(map);
    layerRef.current = layer;
    mapInstanceRef.current = map;

    return () => {
      try {
        mapInstanceRef.current?.stop();
        mapInstanceRef.current?.remove();
        mapInstanceRef.current = null;
      } catch {}
    };
  }, []);

  useEffect(() => {
    const layer = layerRef.current;
    if (!layer) return;
    layer.clearLayers();

    zones.forEach((zone) => {
      const colors = RISK_COLORS[zone.risk_level] || RISK_COLORS.low;
      const isSelected = zone.id === selectedZoneId;

      const circle = L.circleMarker([zone.lat, zone.lng], {
        radius: isSelected ? 14 : 10,
        color: isSelected ? "var(--text-primary)" : colors.stroke,
        weight: isSelected ? 3 : 2,
        fillColor: colors.fill,
        fillOpacity: 0.85,
      });

      const popupHtml = `
        <div style="font-family:'DM Mono',monospace;min-width:180px;padding:2px">
          <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px">
            <strong style="font-size:13px;color:var(--text-primary)">${zone.name}</strong>
            <span style="font-size:9px;padding:2px 6px;border-radius:2px;font-weight:600;background:${colors.fill}44;color:${colors.stroke}">${zone.risk_level.toUpperCase()}</span>
          </div>
          <div style="font-size:10px;color:var(--text-secondary);margin-bottom:6px">${zone.state} · ${zone.lat.toFixed(2)}°N, ${zone.lng.toFixed(2)}°E</div>
          <div style="font-size:11px;margin-bottom:4px;color:var(--text-primary)">Risk Score: <strong>${zone.risk_score.toFixed(1)} / 100</strong></div>
          <div style="font-size:10px;background:var(--surface);border-radius:3px;padding:6px">
            <div>Slope: <strong>${(zone.slope_angle_norm * 45).toFixed(1)}°</strong></div>
            <div>Rainfall 24h: <strong>${(zone.rainfall_24h_norm * 300).toFixed(0)} mm</strong></div>
            <div>Rainfall 7d: <strong>${(zone.rainfall_7d_norm * 500).toFixed(0)} mm</strong></div>
          </div>
        </div>
      `;

      circle.bindPopup(popupHtml);
      circle.on("click", () => onSelectZoneRef.current(zone.id));
      circle.bindTooltip(
        `<span style="font-size:10px;font-weight:600;font-family:'DM Mono',monospace">${zone.name.toUpperCase()} · ${zone.risk_level.toUpperCase()}</span>`,
        { permanent: false, direction: "top", offset: [0, -10] }
      );
      circle.addTo(layer);
    });
  }, [zones, selectedZoneId]);

  return (
    <div className="map-wrapper">
      <div ref={mapRef} className="map-container" />
      <div className="map-hint">
        USE +/- TO ZOOM · CLICK ANYWHERE TO PICK COORDINATES · CLICK ZONES TO INSPECT
      </div>
    </div>
  );
}

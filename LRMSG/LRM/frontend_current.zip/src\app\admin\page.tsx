"use client";

import { mockSystemStatus } from "@/mock/data";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

const STATUS_ICONS: Record<string, { color: string; label: string }> = {
  online: { color: "var(--green)", label: "Online" },
  offline: { color: "var(--red)", label: "Offline" },
  loaded: { color: "var(--green)", label: "Loaded" },
  unloaded: { color: "var(--muted)", label: "Unloaded" },
};

export default function AdminPage() {
  const status = mockSystemStatus();

  return (
    <main>
      <section className="content" style={{ maxWidth: "900px" }}>
        <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
          <div className="section-heading">
            <div>
              <p className="eyebrow">BACKEND &amp; ML SERVICE MONITORING</p>
              <h2>System Status</h2>
            </div>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card" style={{ marginBottom: "20px" }}>
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>SERVICE STATUS</p>
            </div>
            <div style={{ display: "grid", gap: "8px" }}>
              {[
                { label: "FastAPI Backend", value: status.backend },
                { label: "ML Model", value: status.mlModel },
              ].map((svc) => {
                const s = STATUS_ICONS[svc.value] || STATUS_ICONS.offline;
                return (
                  <div key={svc.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", background: "var(--surface)", borderRadius: "3px", border: "1px solid var(--line)" }}>
                    <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "12px", fontWeight: 600, color: "var(--text-primary)" }}>{svc.label}</span>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: s.color }} />
                      <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", color: "var(--text-secondary)" }}>{s.label}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={staggerContainer}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "12px", marginBottom: "20px" }}>
            {[
              { label: "Model Version", value: status.modelVersion },
              { label: "Total Predictions", value: status.totalPredictions.toLocaleString() },
              { label: "Last Update", value: new Date(status.lastUpdate).toLocaleTimeString() },
              { label: "Uptime", value: "99.8%" },
            ].map((item) => (
              <Motion key={item.label} variants={cardReveal}>
                <div className="card" style={{ padding: "14px" }}>
                  <p style={{ fontSize: "10px", fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", margin: "0 0 4px", letterSpacing: "0.5px" }}>{item.label}</p>
                  <p style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "18px", fontWeight: 700, margin: 0, color: "var(--text-primary)" }}>{item.value}</p>
                </div>
              </Motion>
            ))}
          </div>
        </Motion>

        <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
          <div className="card">
            <div style={{ borderBottom: "1px solid var(--line)", paddingBottom: "12px", marginBottom: "16px" }}>
              <p style={{ fontSize: "11px", fontWeight: 700, fontFamily: "'DM Mono', monospace", letterSpacing: "1px", color: "var(--text-secondary)", margin: 0 }}>API ENDPOINTS</p>
            </div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", fontFamily: "'DM Mono', monospace", fontSize: "11px", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid var(--line)" }}>
                    <th style={{ textAlign: "left", padding: "8px 0", color: "var(--text-secondary)", fontWeight: 600 }}>METHOD</th>
                    <th style={{ textAlign: "left", padding: "8px 0", color: "var(--text-secondary)", fontWeight: 600 }}>ENDPOINT</th>
                    <th style={{ textAlign: "left", padding: "8px 0", color: "var(--text-secondary)", fontWeight: 600 }}>DESCRIPTION</th>
                    <th style={{ textAlign: "left", padding: "8px 0", color: "var(--text-secondary)", fontWeight: 600 }}>STATUS</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { method: "GET", path: "/health", desc: "Health check", status: "online" },
                    { method: "POST", path: "/prediction/", desc: "Run ML prediction", status: "online" },
                  ].map((ep) => (
                    <tr key={ep.path} style={{ borderBottom: "1px solid var(--line)" }}>
                      <td style={{ padding: "8px 0" }}>
                        <span style={{ background: "var(--accent)", color: "#fff", padding: "2px 6px", borderRadius: "2px", fontSize: "9px", fontWeight: 700 }}>{ep.method}</span>
                      </td>
                      <td style={{ padding: "8px 0", color: "var(--text-primary)" }}>{ep.path}</td>
                      <td style={{ padding: "8px 0", color: "var(--text-secondary)" }}>{ep.desc}</td>
                      <td style={{ padding: "8px 0" }}>
                        <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "var(--green)", display: "inline-block" }} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Motion>
      </section>
    </main>
  );
}

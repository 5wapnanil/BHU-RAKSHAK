import type { Zone, Alert, Report, RiskLevel, LocationData } from "@/types";

const SOIL_TYPES = ["Acrisols", "Cambisols", "Fluvisols", "Leptosols", "Luvisols", "Vertisols"];

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function pickRisk(score: number): RiskLevel {
  if (score >= 75) return "critical";
  if (score >= 50) return "high";
  if (score >= 30) return "moderate";
  return "low";
}

const LOCATIONS: { name: string; state: string; lat: number; lng: number }[] = [
  { name: "Darjeeling", state: "West Bengal", lat: 27.041, lng: 88.2663 },
  { name: "Gangtok", state: "Sikkim", lat: 27.3389, lng: 88.6065 },
  { name: "Shillong", state: "Meghalaya", lat: 25.5788, lng: 91.8933 },
  { name: "Kohima", state: "Nagaland", lat: 25.6586, lng: 94.1086 },
  { name: "Aizawl", state: "Mizoram", lat: 23.7271, lng: 92.7176 },
  { name: "Itanagar", state: "Arunachal Pradesh", lat: 27.1044, lng: 93.692 },
  { name: "Imphal", state: "Manipur", lat: 24.817, lng: 93.9368 },
  { name: "Agartala", state: "Tripura", lat: 23.8315, lng: 91.2868 },
  { name: "Guwahati", state: "Assam", lat: 26.1445, lng: 91.7362 },
  { name: "Champhai", state: "Mizoram", lat: 23.4917, lng: 93.2045 },
  { name: "Dhemaji", state: "Assam", lat: 27.5547, lng: 94.2599 },
  { name: "Lower Dibang Valley", state: "Arunachal Pradesh", lat: 28.2333, lng: 95.7776 },
  { name: "East Jaintia Hills", state: "Meghalaya", lat: 25.1059, lng: 92.3602 },
  { name: "West Kameng", state: "Arunachal Pradesh", lat: 27.25, lng: 92.42 },
  { name: "North Tripura", state: "Tripura", lat: 24.27, lng: 92.16 },
];

export function mockZones(): Zone[] {
  return LOCATIONS.map((loc, i) => {
    const score = Math.round(rand(5, 95));
    return {
      id: i + 1,
      name: loc.name,
      state: loc.state,
      lat: loc.lat,
      lng: loc.lng,
      slope_angle_norm: rand(0.1, 0.9),
      rainfall_24h_norm: rand(0, 1),
      rainfall_7d_norm: rand(0, 1),
      risk_score: score,
      risk_level: pickRisk(score),
    };
  });
}

export function mockAlerts(): Alert[] {
  return [
    {
      id: "alert-1",
      severity: "critical",
      location: "Darjeeling, West Bengal",
      message: "Heavy rainfall detected. Soil moisture saturation at critical levels. High probability of slope failure.",
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      riskChange: { from: "high", to: "critical" },
    },
    {
      id: "alert-2",
      severity: "high",
      location: "Gangtok, Sikkim",
      message: "Persistent rainfall over 72 hours. Soil moisture increasing steadily.",
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      riskChange: { from: "moderate", to: "high" },
    },
    {
      id: "alert-3",
      severity: "moderate",
      location: "Shillong, Meghalaya",
      message: "Moderate rainfall expected over next 48 hours. Monitor conditions.",
      timestamp: new Date(Date.now() - 14400000).toISOString(),
    },
    {
      id: "alert-4",
      severity: "info",
      location: "Kohima, Nagaland",
      message: "Seasonal monsoon pattern detected. Baseline risk assessment updated.",
      timestamp: new Date(Date.now() - 28800000).toISOString(),
    },
  ];
}

export function mockReports(): Report[] {
  return [
    { id: "rpt-1", location: "Darjeeling", date: "2026-09-04", riskLevel: "high", probability: 0.78, status: "generated" },
    { id: "rpt-2", location: "Gangtok", date: "2026-09-03", riskLevel: "moderate", probability: 0.45, status: "generated" },
    { id: "rpt-3", location: "Shillong", date: "2026-09-03", riskLevel: "low", probability: 0.22, status: "generated" },
    { id: "rpt-4", location: "Aizawl", date: "2026-09-02", riskLevel: "high", probability: 0.71, status: "generated" },
    { id: "rpt-5", location: "Kohima", date: "2026-09-02", riskLevel: "moderate", probability: 0.38, status: "pending" },
  ];
}

export function mockSystemStatus() {
  return {
    backend: "online" as const,
    mlModel: "loaded" as const,
    lastUpdate: new Date().toISOString(),
    totalPredictions: 12847,
    modelVersion: "v1.0.0",
  };
}

export function mockModelMetrics() {
  return {
    accuracy: 0.953,
    precision: 0.932,
    recall: 0.938,
    f1: 0.935,
    rocAuc: 0.986,
    prAuc: 0.965,
  };
}

export function mockSoilTypes() {
  return SOIL_TYPES;
}

export function mockLocations(): LocationData[] {
  return LOCATIONS.map((loc) => ({
    name: loc.name,
    state: loc.state,
    district: loc.name,
    latitude: loc.lat,
    longitude: loc.lng,
  }));
}

export interface AnalyticsSummary {
  monitoredLocations: number;
  highRiskAreas: number;
  moderateRiskAreas: number;
  lowRiskAreas: number;
  highRiskChange: number;
  moderateRiskChange: number;
  lowRiskChange: number;
}

export interface RiskDistribution {
  name: string;
  value: number;
  color: string;
}

export interface ProbabilityDistribution {
  range: string;
  count: number;
}

export interface RainfallRiskTrend {
  date: string;
  rainfall: number;
  riskScore: number;
}

export interface RegionalRisk {
  state: string;
  avgRisk: number;
  locations: number;
}

export interface HistorySummary {
  totalEvents: number;
  landslideEvents: number;
  avgRiskScore: number;
}

export interface RainfallHistory {
  date: string;
  rainfall: number;
}

export interface RiskScoreOverTime {
  date: string;
  riskScore: number;
  threshold: number;
}

export interface LandslideEvent {
  date: string;
  rainfall: number;
  soilMoisture: number;
  riskScore: number;
}

export function mockAnalyticsSummary(): AnalyticsSummary {
  return {
    monitoredLocations: 12480,
    highRiskAreas: 1284,
    moderateRiskAreas: 4812,
    lowRiskAreas: 6384,
    highRiskChange: 12,
    moderateRiskChange: 0,
    lowRiskChange: -8,
  };
}

export function mockRiskDistribution(): RiskDistribution[] {
  return [
    { name: "High", value: 11, color: "#DC2626" },
    { name: "Low", value: 3, color: "#3FB950" },
    { name: "Moderate", value: 1, color: "#D29922" },
  ];
}

export function mockProbabilityDistribution(): ProbabilityDistribution[] {
  return [
    { range: "0-20%", count: 0 },
    { range: "20-40%", count: 1 },
    { range: "40-60%", count: 2 },
    { range: "60-80%", count: 7 },
    { range: "80-100%", count: 2 },
  ];
}

export function mockRainfallRiskTrend(): RainfallRiskTrend[] {
  const data: RainfallRiskTrend[] = [];
  const startDate = new Date("2023-01-01");
  const endDate = new Date("2024-09-29");
  
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 30)) {
    const month = d.getMonth();
    const isMonsoon = month >= 5 && month <= 9;
    const baseRainfall = isMonsoon ? 180 : 60;
    const rainfall = Math.round(baseRainfall + rand(-40, 80));
    const riskScore = Math.round(30 + (rainfall / 360) * 70 + rand(-10, 10));
    
    data.push({
      date: d.toISOString().split("T")[0],
      rainfall: Math.max(0, rainfall),
      riskScore: Math.min(100, Math.max(0, riskScore)),
    });
  }
  return data;
}

export function mockRegionalRisk(): RegionalRisk[] {
  return [
    { state: "Arunachal Pradesh", avgRisk: 72, locations: 3 },
    { state: "Assam", avgRisk: 45, locations: 2 },
    { state: "Manipur", avgRisk: 58, locations: 1 },
    { state: "Meghalaya", avgRisk: 68, locations: 2 },
    { state: "Mizoram", avgRisk: 63, locations: 2 },
    { state: "Nagaland", avgRisk: 52, locations: 1 },
    { state: "Sikkim", avgRisk: 75, locations: 1 },
    { state: "Tripura", avgRisk: 42, locations: 2 },
    { state: "West Bengal", avgRisk: 81, locations: 1 },
  ];
}

export function mockHistorySummary(): HistorySummary {
  return {
    totalEvents: 100,
    landslideEvents: 5,
    avgRiskScore: 37,
  };
}

export function mockRainfallHistory(): RainfallHistory[] {
  const data: RainfallHistory[] = [];
  const startDate = new Date("2023-01-01");
  const endDate = new Date("2024-09-29");
  
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 7)) {
    const month = d.getMonth();
    const isMonsoon = month >= 5 && month <= 9;
    const baseRainfall = isMonsoon ? 200 : 50;
    const rainfall = Math.round(baseRainfall + rand(-80, 120));
    
    data.push({
      date: d.toISOString().split("T")[0],
      rainfall: Math.max(0, rainfall),
    });
  }
  return data;
}

export function mockRiskScoreOverTime(): RiskScoreOverTime[] {
  const data: RiskScoreOverTime[] = [];
  const startDate = new Date("2023-01-01");
  const endDate = new Date("2024-09-29");
  
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 7)) {
    const riskScore = rand(0.15, 0.85);
    
    data.push({
      date: d.toISOString().split("T")[0],
      riskScore: Math.round(riskScore * 100) / 100,
      threshold: 0.5,
    });
  }
  return data;
}

export function mockLandslideEvents(): LandslideEvent[] {
  return [
    { date: "2023-06-18", rainfall: 102, soilMoisture: 74, riskScore: 82 },
    { date: "2023-07-16", rainfall: 211, soilMoisture: 74, riskScore: 76 },
    { date: "2023-08-13", rainfall: 127, soilMoisture: 76, riskScore: 81 },
    { date: "2024-06-09", rainfall: 156, soilMoisture: 71, riskScore: 79 },
    { date: "2024-07-28", rainfall: 198, soilMoisture: 78, riskScore: 85 },
  ];
}

"use client";

import { useState, useMemo } from "react";
import { ARTICLES, CATEGORIES, searchArticles, filterByCategory } from "@/data/articles";
import { ArticleCard } from "@/components/insights/ArticleCard";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

export default function InsightsPage() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("ALL");

  const filtered = useMemo(() => {
    let result = activeCategory === "ALL" ? [...ARTICLES] : filterByCategory(activeCategory);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.category.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q)
      );
    }
    return result;
  }, [search, activeCategory]);

  return (
    <div className="content" style={{ maxWidth: "1200px", margin: "0 auto" }}>
      <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
        <div style={{ marginBottom: "32px" }}>
          <p className="eyebrow">RESEARCH &amp; INSIGHTS</p>
          <h1 style={{ font: "600 28px 'Space Grotesk'", color: "var(--text-primary)", margin: "0 0 8px" }}>
            Research &amp; Insights
          </h1>
          <p style={{ fontSize: "14px", fontFamily: "'DM Sans', sans-serif", color: "var(--text-secondary)", lineHeight: 1.6, maxWidth: "600px" }}>
            Explore the science, environmental signals, GIS technologies, and machine-learning approaches behind modern landslide risk assessment and monitoring.
          </p>
        </div>
      </Motion>

      <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4, delay: 0.1 }}>
        <div style={{ display: "flex", gap: "12px", alignItems: "center", marginBottom: "24px", flexWrap: "wrap" }}>
          <input
            type="text"
            placeholder="Search articles..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search articles"
            style={{
              fontFamily: "'DM Mono', monospace",
              fontSize: "12px",
              padding: "8px 12px",
              border: "1px solid var(--card-border)",
              background: "var(--card-bg)",
              color: "var(--text-primary)",
              borderRadius: "3px",
              outline: "none",
              minWidth: "250px",
            }}
          />
        </div>
      </Motion>

      <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4, delay: 0.15 }}>
        <div style={{ display: "flex", gap: "8px", marginBottom: "24px", flexWrap: "wrap" }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`chip ${activeCategory === cat ? "active" : ""}`}
              aria-label={`Filter by ${cat}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </Motion>

      {filtered.length === 0 ? (
        <p style={{ fontSize: "13px", fontFamily: "'DM Sans', sans-serif", color: "var(--text-secondary)", textAlign: "center", padding: "48px 0" }}>
          No articles found matching your search.
        </p>
      ) : (
        <Motion initial="hidden" animate="visible" variants={staggerContainer}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "16px" }}>
            {filtered.map((article) => (
              <Motion key={article.id} variants={cardReveal}>
                <ArticleCard article={article} />
              </Motion>
            ))}
          </div>
        </Motion>
      )}
    </div>
  );
}

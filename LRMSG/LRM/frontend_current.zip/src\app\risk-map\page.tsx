"use client";

import { useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { mockZones, mockLocations } from "@/mock/data";
import type { Zone } from "@/types";
import { Search } from "lucide-react";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

const RiskMap = dynamic(() => import("@/components/map/RiskMap"), {
  ssr: false,
  loading: () => <div className="map-placeholder">LOADING RISK MAP…</div>,
});

export default function RiskMapPage() {
  const [zones] = useState<Zone[]>(mockZones());
  const [selectedZoneId, setSelectedZoneId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [analyzing, setAnalyzing] = useState(false);

  const filteredZones = zones.filter(
    (z) =>
      z.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      z.state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedZone = selectedZoneId !== null ? zones.find((z) => z.id === selectedZoneId) ?? null : null;

  const handleSelectZone = useCallback((id: number) => {
    setSelectedZoneId(id);
  }, []);

  const handleLocationSelect = useCallback((lat: number, lng: number) => {
    // Find nearest zone
    let nearest = zones[0];
    let minDist = Infinity;
    zones.forEach((z) => {
      const d = Math.abs(z.lat - lat) + Math.abs(z.lng - lng);
      if (d < minDist) { minDist = d; nearest = z; }
    });
    setSelectedZoneId(nearest.id);
  }, [zones]);

  return (
    <main>
      <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
        <section className="content" style={{ paddingBottom: "2vh" }}>
          <div className="section-heading">
            <div>
              <p className="eyebrow">NORTHEAST INDIA GEOSPATIAL VIEW</p>
              <h2>District Risk Map</h2>
            </div>
            <div className="legend">
              <span className="dot low" />NORMAL
              <span className="dot watch" />WATCH
              <span className="dot high" />WARNING
              <span className="dot critical" />CRITICAL
            </div>
          </div>
        </section>
      </Motion>

      <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
        <section className="filter-bar">
          <label>SEARCH:</label>
          <input type="text" placeholder="Search district or state…" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} style={{ minWidth: "200px" }} />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} style={{ fontSize: "10px", padding: "5px 10px", border: "1px solid var(--line)", borderRadius: "3px", background: "var(--card-bg)", color: "var(--text-secondary)", cursor: "pointer" }}>
              CLEAR ×
            </button>
          )}
          <span style={{ marginLeft: "auto", fontSize: "11px", color: "var(--text-secondary)", fontFamily: "'DM Mono', monospace" }}>
            Showing <strong style={{ color: "var(--text-primary)" }}>{filteredZones.length}</strong> of <strong style={{ color: "var(--text-primary)" }}>{zones.length}</strong> districts
          </span>
        </section>
      </Motion>

      <Motion initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeInUp}>
        <section style={{ padding: "0 5vw" }}>
          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: "0", border: "1px solid var(--card-border)", background: "var(--card-bg)", overflow: "hidden" }}>
            {/* Sidebar */}
            <div style={{ borderRight: "1px solid var(--card-border)", maxHeight: "540px", overflowY: "auto" }}>
              <div style={{ padding: "12px 14px", borderBottom: "1px solid var(--card-border)", background: "var(--surface)" }}>
                <span style={{ fontSize: "10px", fontWeight: 700, fontFamily: "'DM Mono', monospace", color: "var(--text-secondary)", letterSpacing: "1px" }}>DISTRICTS</span>
              </div>
              {filteredZones.map((zone) => {
                const isSelected = zone.id === selectedZoneId;
                return (
                  <button
                    key={zone.id}
                    onClick={() => handleSelectZone(zone.id)}
                    className="w-full text-left"
                    style={{
                      padding: "10px 14px",
                      borderBottom: "1px solid var(--line)",
                      background: isSelected ? "var(--accent)" : "transparent",
                      color: isSelected ? "#fff" : "var(--text-primary)",
                      cursor: "pointer",
                      fontFamily: "'DM Mono', monospace",
                      fontSize: "11px",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 600 }}>{zone.name.toUpperCase()}</div>
                      <div style={{ fontSize: "9px", opacity: 0.7, marginTop: "2px" }}>{zone.state}</div>
                    </div>
                    <span
                      className={`level-tag ${zone.risk_level}`}
                      style={{ fontSize: "9px", padding: "2px 6px" }}
                    >
                      {zone.risk_level === "critical" ? "CRIT" : zone.risk_level.toUpperCase()}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Map */}
            <div>
              <RiskMap
                zones={filteredZones}
                selectedZoneId={selectedZoneId}
                onSelectZone={handleSelectZone}
                onLocationSelect={handleLocationSelect}
              />
            </div>
          </div>
        </section>
      </Motion>

      {/* Selected District Detail */}
      {selectedZone && (
        <Motion initial="hidden" animate="visible" variants={fadeInUp}>
          <section className="content">
            <div className="card" style={{ overflow: "hidden", padding: 0 }}>
              <div style={{ background: selectedZone.risk_level === "critical" ? "var(--red)" : selectedZone.risk_level === "high" ? "#F97316" : selectedZone.risk_level === "moderate" ? "var(--amber)" : "var(--green)", height: "4px" }} />
              <div style={{ padding: "24px 32px", display: "flex", justifyContent: "space-between", alignItems: "flex-start", borderBottom: "1px solid var(--line)", background: "var(--surface)", flexWrap: "wrap", gap: "16px" }}>
                <div>
                  <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "28px", fontWeight: 600, margin: 0, letterSpacing: "-1px", color: "var(--text-primary)" }}>{selectedZone.name}</h2>
                  <div style={{ display: "flex", gap: "10px", alignItems: "center", marginTop: "8px", flexWrap: "wrap" }}>
                    <span style={{ background: "var(--surface)", color: "var(--accent-text)", fontFamily: "'DM Mono', monospace", fontWeight: 700, fontSize: "10px", padding: "4px 8px", borderRadius: "3px", letterSpacing: "0.06em", border: "1px solid var(--line)" }}>{selectedZone.state.toUpperCase()}</span>
                    <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", color: "var(--text-secondary)" }}>{selectedZone.lat.toFixed(2)}°N / {selectedZone.lng.toFixed(2)}°E</span>
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: "48px", fontWeight: 700, lineHeight: 1, letterSpacing: "-2px", color: "var(--text-primary)" }}>{selectedZone.risk_score.toFixed(0)}</div>
                  <span style={{ fontFamily: "'DM Mono', monospace", fontWeight: 600, fontSize: "9px", letterSpacing: "1px", color: "var(--text-secondary)" }}>RISK SCORE (/100)</span>
                  <div style={{ marginTop: "8px" }}>
                    <span className={`level-tag ${selectedZone.risk_level}`} style={{ fontSize: "11px", padding: "6px 12px" }}>
                      {selectedZone.risk_level.toUpperCase()} RISK
                    </span>
                  </div>
                </div>
              </div>

              {/* Environmental conditions */}
              <div style={{ padding: "16px 32px", display: "flex", gap: "24px", flexWrap: "wrap", borderBottom: "1px solid var(--line)", background: "var(--surface)" }}>
                <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "9px", fontWeight: 700, background: "var(--accent)", color: "#fff", padding: "3px 8px", borderRadius: "2px" }}>ENVIRONMENTAL</span>
                <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", color: "var(--text-secondary)" }}>Slope: <b style={{ color: "var(--text-primary)" }}>{(selectedZone.slope_angle_norm * 45).toFixed(1)}°</b></span>
                <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", color: "var(--text-secondary)" }}>Rainfall 24h: <b style={{ color: "var(--text-primary)" }}>{(selectedZone.rainfall_24h_norm * 300).toFixed(0)} mm</b></span>
                <span style={{ fontFamily: "'DM Mono', monospace", fontSize: "11px", color: "var(--text-secondary)" }}>Rainfall 7d: <b style={{ color: "var(--text-primary)" }}>{(selectedZone.rainfall_7d_norm * 500).toFixed(0)} mm</b></span>
              </div>

              {/* XAI breakdown */}
              <div style={{ padding: "14px 32px", display: "flex", gap: "14px", alignItems: "center", flexWrap: "wrap", fontFamily: "'DM Mono', monospace", fontSize: "11px", borderBottom: "1px solid var(--line)" }}>
                <span style={{ background: "var(--accent)", color: "#fff", fontWeight: 700, fontSize: "9px", padding: "3px 8px", borderRadius: "2px", letterSpacing: "1px" }}>XAI RISK DRIVERS</span>
                {[
                  { label: "Terrain Slope", pct: Math.round(selectedZone.slope_angle_norm * 30) },
                  { label: "24h Rainfall", pct: Math.round(selectedZone.rainfall_24h_norm * 35) },
                  { label: "7d Antecedent", pct: Math.round(selectedZone.rainfall_7d_norm * 20) },
                  { label: "Historical", pct: Math.max(0, 100 - Math.round(selectedZone.slope_angle_norm * 30) - Math.round(selectedZone.rainfall_24h_norm * 35) - Math.round(selectedZone.rainfall_7d_norm * 20)) },
                ].map((d, i) => (
                  <span key={d.label} style={{ color: "var(--text-secondary)" }}>
                    {i > 0 && <span style={{ color: "var(--line)", margin: "0 4px" }}>·</span>}
                    {d.label} <b style={{ color: "var(--text-primary)" }}>{d.pct}%</b>
                  </span>
                ))}
              </div>

              {/* Required action */}
              <div style={{
                padding: "14px 32px",
                background: selectedZone.risk_level === "critical" ? "rgba(248,81,73,0.1)" : selectedZone.risk_level === "high" ? "rgba(249,115,22,0.1)" : selectedZone.risk_level === "moderate" ? "rgba(210,153,34,0.1)" : "rgba(63,185,80,0.1)",
                display: "flex", alignItems: "center", gap: "14px", flexWrap: "wrap",
              }}>
                <span style={{
                  fontSize: "10px", fontWeight: 700, fontFamily: "'DM Mono', monospace",
                  padding: "4px 10px", borderRadius: "3px",
                  background: selectedZone.risk_level === "critical" ? "var(--red)" : selectedZone.risk_level === "high" ? "#F97316" : selectedZone.risk_level === "moderate" ? "var(--amber)" : "var(--green)",
                  color: "#fff", letterSpacing: "0.8px",
                }}>
                  REQUIRED ACTION ({selectedZone.risk_level.toUpperCase()})
                </span>
                <span style={{ fontSize: "12px", fontWeight: 600, fontFamily: "'DM Mono', monospace", color: "var(--text-primary)", lineHeight: 1.5 }}>
                  {selectedZone.risk_level === "critical" && "CRITICAL: Sound sirens, send emergency alerts, restrict highway access, initiate mandatory evacuation."}
                  {selectedZone.risk_level === "high" && "HIGH THREAT: Restrict traffic, deploy rescue teams, open relief centers, alert hillside habitations."}
                  {selectedZone.risk_level === "moderate" && "WATCH: Monitor soil saturation, alert village panchayats, standby rapid response teams."}
                  {selectedZone.risk_level === "low" && "ROUTINE: Parameters within safe limits. Continue automated monitoring."}
                </span>
              </div>
            </div>
          </section>
        </Motion>
      )}
    </main>
  );
}

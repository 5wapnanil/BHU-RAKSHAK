"use client";

import { use } from "react";
import Link from "next/link";
import { getArticleBySlug, getRelatedArticles, ARTICLES } from "@/data/articles";
import { ArticleCard } from "@/components/insights/ArticleCard";
import { Motion } from "@/components/ui/Motion";
import { fadeInUp, staggerContainer, cardReveal } from "@/animations/variants";

export default function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const article = getArticleBySlug(slug);

  if (!article) {
    return (
      <div className="content" style={{ maxWidth: "800px", margin: "0 auto", textAlign: "center", padding: "80px 20px" }}>
        <h1 style={{ font: "600 28px 'Space Grotesk'", color: "var(--text-primary)", marginBottom: "16px" }}>
          Article Not Found
        </h1>
        <p style={{ fontSize: "14px", fontFamily: "'DM Sans', sans-serif", color: "var(--text-secondary)", marginBottom: "24px" }}>
          The article you are looking for does not exist or has been moved.
        </p>
        <Link
          href="/insights"
          style={{
            fontFamily: "'DM Mono', monospace",
            fontSize: "11px",
            fontWeight: 700,
            letterSpacing: "1px",
            padding: "12px 24px",
            background: "var(--accent)",
            color: "#fff",
            border: "none",
            borderRadius: "3px",
            textDecoration: "none",
            cursor: "pointer",
          }}
        >
          BACK TO INSIGHTS
        </Link>
      </div>
    );
  }

  const related = getRelatedArticles(article, 3);

  return (
    <div className="content" style={{ maxWidth: "800px", margin: "0 auto" }}>
      <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4 }}>
        <nav style={{ marginBottom: "32px" }}>
          <Link
            href="/insights"
            style={{
              fontFamily: "'DM Mono', monospace",
              fontSize: "10px",
              fontWeight: 700,
              letterSpacing: "1px",
              color: "var(--accent-text)",
              textDecoration: "none",
            }}
          >
            ← BACK TO INSIGHTS
          </Link>
        </nav>
      </Motion>

      <article>
        <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4, delay: 0.1 }}>
          <header style={{ marginBottom: "32px" }}>
            <p className="eyebrow">{article.category}</p>
            <h1 style={{ font: "600 28px 'Space Grotesk'", color: "var(--text-primary)", margin: "0 0 12px", lineHeight: 1.3 }}>
              {article.title}
            </h1>
            <div style={{ display: "flex", gap: "16px", alignItems: "center", fontFamily: "'DM Mono', monospace", fontSize: "10px", color: "var(--text-secondary)" }}>
              <span>{article.publishedAt}</span>
              <span>·</span>
              <span>{article.readTime}</span>
              <span>·</span>
              <span>{article.author}</span>
            </div>
          </header>
        </Motion>

        <Motion initial="hidden" animate="visible" variants={fadeInUp} transition={{ duration: 0.4, delay: 0.2 }}>
          <div style={{ borderTop: "1px solid var(--line)", paddingTop: "32px" }}>
            {article.content.map((section, i) => (
              <section key={i} style={{ marginBottom: "32px" }}>
                <h2 style={{ font: "600 18px 'Space Grotesk'", color: "var(--text-primary)", margin: "0 0 12px" }}>
                  {section.heading}
                </h2>
                {section.content.map((paragraph, j) => (
                  <p key={j} style={{ fontSize: "14px", fontFamily: "'DM Sans', sans-serif", color: "var(--text-secondary)", lineHeight: 1.7, margin: "0 0 12px" }}>
                    {paragraph}
                  </p>
                ))}
              </section>
            ))}
          </div>
        </Motion>
      </article>

      {related.length > 0 && (
        <Motion initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
          <section style={{ borderTop: "1px solid var(--line)", paddingTop: "32px", marginTop: "48px" }}>
            <h2 style={{ font: "600 20px 'Space Grotesk'", color: "var(--text-primary)", margin: "0 0 20px" }}>
              Related Insights
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "16px" }}>
              {related.map((a) => (
                <Motion key={a.id} variants={cardReveal}>
                  <ArticleCard article={a} />
                </Motion>
              ))}
            </div>
          </section>
        </Motion>
      )}
    </div>
  );
}
